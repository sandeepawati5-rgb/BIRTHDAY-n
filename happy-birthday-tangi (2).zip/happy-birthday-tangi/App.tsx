
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { PageId } from './types';
import Background from './components/Background';
import Fireworks from './components/Fireworks';
import { Heart, Sparkles, Star, ChevronRight, ChevronLeft } from 'lucide-react';

const ABOUT_ITEMS = [
  { 
    text: "Soft heart, genuine soul", 
    icon: <Heart className="w-5 h-5 text-rose-300" />,
    image: "https://images.unsplash.com/photo-1490750967868-88aa4486c946?auto=format&fit=crop&q=80&w=800"
  },
  { 
    text: "Quiet strength, beautiful smile", 
    icon: <Star className="w-5 h-5 text-rose-300" />,
    image: "https://images.unsplash.com/photo-1502082553048-f009c37129b9?auto=format&fit=crop&q=80&w=800"
  },
  { 
    text: "Kindness that feels real", 
    icon: <Sparkles className="w-5 h-5 text-rose-300" />,
    image: "https://images.unsplash.com/photo-1516733958028-966f045a56f1?auto=format&fit=crop&q=80&w=800"
  },
  { 
    text: "Family by choice, not chance", 
    icon: <Heart className="w-5 h-5 text-rose-300" />,
    image: "https://images.unsplash.com/photo-1511632765486-a01980e01a18?auto=format&fit=crop&q=80&w=800"
  },
  { 
    text: "Someone worth standing for", 
    icon: <Star className="w-5 h-5 text-rose-300" />,
    image: "https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?auto=format&fit=crop&q=80&w=800"
  }
];

const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<PageId>(PageId.OPENING);
  const [carouselIndex, setCarouselIndex] = useState(0);

  const next = () => {
    if (currentPage < PageId.FINAL) {
      setCurrentPage(currentPage + 1);
    }
  };

  const pageTransition = {
    initial: { opacity: 0 },
    animate: { opacity: 1 },
    exit: { opacity: 0 },
    transition: { duration: 0.8, ease: "easeOut" }
  } as const;

  const titleAnim = {
    initial: { opacity: 0, y: 30 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 1.2, ease: "easeOut", delay: 0.2 }
  } as const;

  const nextCarousel = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (carouselIndex < ABOUT_ITEMS.length - 1) {
      setCarouselIndex(carouselIndex + 1);
    }
  };

  const prevCarousel = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (carouselIndex > 0) {
      setCarouselIndex(carouselIndex - 1);
    }
  };

  // Higher intensity for celebratory slides
  const currentIntensity = (currentPage === PageId.AGE || currentPage === PageId.FINAL || currentPage === PageId.OPENING) ? 0.9 : 0.4;

  return (
    <div className="relative w-screen h-screen overflow-hidden text-rose-800">
      <Background />
      
      {/* Skyshots now active on ALL slides with enhanced intensity */}
      <Fireworks intensity={currentIntensity} />

      <AnimatePresence mode="wait">
        <motion.div
          key={currentPage}
          className="relative z-10 w-full h-full flex flex-col items-center justify-center p-6 text-center"
          {...pageTransition}
        >
          {/* Page 1: Opening Screen */}
          {currentPage === PageId.OPENING && (
            <div className="flex flex-col items-center gap-12">
              <div className="relative">
                <motion.h1 
                  className="text-6xl md:text-7xl font-cursive glow-text leading-tight text-rose-500 z-10 relative"
                  {...titleAnim}
                >
                  Happy Birthday Tangi 💖
                </motion.h1>
                <DecorationSparkles count={12} />
              </div>
              <NextButton onClick={next} label="Tap to Continue ✨" />
            </div>
          )}

          {/* Page 2: Name Reveal */}
          {currentPage === PageId.NAME_REVEAL && (
            <div className="space-y-10 relative">
              <div className="space-y-4">
                <motion.h2 
                  className="text-7xl font-cursive text-rose-500 glow-text"
                  {...titleAnim}
                >
                  Payal 🤍
                </motion.h2>
                <motion.h3 
                  className="text-4xl font-cursive text-rose-400"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.6, duration: 1 }}
                >
                  Paapu 🌸
                </motion.h3>
              </div>
              <DecorationSparkles scale={1.2} count={8} />
              <NextButton onClick={next} label="Next" />
            </div>
          )}

          {/* Page 3: Emotional Intro */}
          {currentPage === PageId.INTRO && (
            <div className="max-w-xs md:max-w-md space-y-12 relative">
              <motion.div 
                className="text-2xl md:text-3xl font-serif italic leading-relaxed text-rose-700 glass p-10 rounded-[3rem]"
                {...titleAnim}
              >
                “Some people become family <br/>
                <span className="text-rose-400 not-italic font-cursive text-4xl mt-2 block">not by birth,</span><br/>
                but by heart.”
              </motion.div>
              <NextButton onClick={next} label="Continue" />
            </div>
          )}

          {/* Page 4: Emotional Message */}
          {currentPage === PageId.MESSAGE && (
            <div className="max-w-sm text-left glass p-10 rounded-[2.5rem] space-y-6 relative overflow-hidden">
              <div className="absolute top-0 right-0 p-4 opacity-20">
                <Heart className="w-24 h-24 text-rose-300" />
              </div>
              <motion.p 
                className="text-3xl font-cursive text-rose-500"
                {...titleAnim}
              >
                Dear Paapu,
              </motion.p>
              {[
                "You may not share my blood,",
                "but you share my respect, care, and space in life.",
                "These past few months were enough to show me that bonds don’t need years —",
                "they just need honesty.",
                "You became someone I genuinely care about, and that makes you family to me."
              ].map((line, i) => (
                <motion.p
                  key={i}
                  className="text-base font-light leading-relaxed"
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: (i + 1) * 0.4 + 0.5 }}
                >
                  {line}
                </motion.p>
              ))}
              <div className="pt-6 text-center">
                <NextButton onClick={next} label="Continue" />
              </div>
            </div>
          )}

          {/* Page 5: About Her Carousel */}
          {currentPage === PageId.ABOUT && (
            <div className="w-full max-w-sm flex flex-col items-center">
              <motion.h2 
                className="text-4xl font-cursive mb-8 text-rose-500 glow-text"
                {...titleAnim}
              >
                About You...
              </motion.h2>
              
              <motion.div 
                className="relative w-full aspect-[3/4] overflow-hidden rounded-[2.5rem] glass shadow-2xl border-2 border-white/50"
                initial={{ opacity: 0, scale: 0.9, y: 20 }}
                animate={{ opacity: 1, scale: 1, y: 0 }}
                transition={{ duration: 0.8, delay: 0.5 }}
              >
                <AnimatePresence mode="wait">
                  <motion.div
                    key={carouselIndex}
                    initial={{ opacity: 0, scale: 1.1 }}
                    animate={{ opacity: 1, scale: 1 }}
                    exit={{ opacity: 0, scale: 0.95 }}
                    transition={{ duration: 0.6 }}
                    className="absolute inset-0 flex flex-col"
                  >
                    <img 
                      src={ABOUT_ITEMS[carouselIndex].image} 
                      alt={ABOUT_ITEMS[carouselIndex].text}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-rose-950/70 via-rose-900/20 to-transparent" />
                    <div className="absolute bottom-0 left-0 right-0 p-10 text-white text-left">
                      <motion.div 
                        initial={{ y: 20, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        className="bg-white/20 backdrop-blur-xl w-12 h-12 rounded-2xl flex items-center justify-center mb-4 border border-white/30"
                      >
                        {ABOUT_ITEMS[carouselIndex].icon}
                      </motion.div>
                      <motion.p 
                        initial={{ y: 10, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        transition={{ delay: 0.2 }}
                        className="text-2xl font-serif italic tracking-wide leading-snug"
                      >
                        {ABOUT_ITEMS[carouselIndex].text}
                      </motion.p>
                    </div>
                  </motion.div>
                </AnimatePresence>

                {/* Carousel Controls Overlay */}
                <div className="absolute inset-0 flex items-center justify-between px-6 pointer-events-none">
                  <button 
                    onClick={prevCarousel}
                    disabled={carouselIndex === 0}
                    className={`pointer-events-auto w-12 h-12 rounded-full glass flex items-center justify-center transition-all ${carouselIndex === 0 ? 'opacity-0 scale-50' : 'opacity-100 scale-100'}`}
                  >
                    <ChevronLeft className="w-6 h-6 text-white" />
                  </button>
                  <button 
                    onClick={nextCarousel}
                    disabled={carouselIndex === ABOUT_ITEMS.length - 1}
                    className={`pointer-events-auto w-12 h-12 rounded-full glass flex items-center justify-center transition-all ${carouselIndex === ABOUT_ITEMS.length - 1 ? 'opacity-0 scale-50' : 'opacity-100 scale-100'}`}
                  >
                    <ChevronRight className="w-6 h-6 text-white" />
                  </button>
                </div>

                {/* Dots */}
                <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-3">
                  {ABOUT_ITEMS.map((_, i) => (
                    <div 
                      key={i} 
                      className={`h-1.5 rounded-full transition-all duration-500 ${i === carouselIndex ? 'w-10 bg-white shadow-[0_0_10px_white]' : 'w-2 bg-white/40'}`} 
                    />
                  ))}
                </div>
              </motion.div>

              <div className="mt-8 flex flex-col items-center gap-4">
                {carouselIndex === ABOUT_ITEMS.length - 1 ? (
                  <NextButton onClick={next} label="Next Chapter" />
                ) : (
                  <motion.p 
                    animate={{ opacity: [0.4, 1, 0.4] }}
                    transition={{ duration: 2, repeat: Infinity }}
                    className="text-xs uppercase tracking-[0.3em] text-rose-300 font-bold"
                  >
                    Explore the cards
                  </motion.p>
                )}
              </div>
            </div>
          )}

          {/* Page 6: Promise From the Heart */}
          {currentPage === PageId.PROMISE && (
            <div className="max-w-xs md:max-w-md space-y-12 relative">
              <DecorationSparkles scale={0.8} count={10} />
              <motion.div
                className="text-xl leading-relaxed space-y-8 font-serif italic glass p-10 rounded-[3rem]"
                initial="hidden"
                animate="visible"
                variants={{
                  visible: { transition: { staggerChildren: 0.8 } }
                }}
              >
                <motion.p 
                  className="font-semibold text-rose-500 text-2xl"
                  variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}
                  transition={{ duration: 1 }}
                >
                  “I won’t claim a place I didn’t earn, but I’ll always offer respect, support, and care.”
                </motion.p>
                <motion.p 
                  className="text-rose-400"
                  variants={{ hidden: { opacity: 0, y: 20 }, visible: { opacity: 1, y: 0 } }}
                >
                  “I’ll stand beside you, cheer for you, and wish the best for you — silently or loudly, whenever needed.”
                </motion.p>
              </motion.div>
              <NextButton onClick={next} label="Continue" />
            </div>
          )}

          {/* Page 7: Turning 19 */}
          {currentPage === PageId.AGE && (
            <div className="space-y-10 relative">
              <motion.div
                className="glass p-12 rounded-full w-56 h-56 flex flex-col items-center justify-center border-4 border-white/60 shadow-[0_0_50px_rgba(255,182,193,0.5)] relative"
                {...titleAnim}
              >
                <motion.div 
                  animate={{ scale: [1, 1.3, 1], opacity: [0.4, 0.7, 0.4] }}
                  transition={{ duration: 5, repeat: Infinity }}
                  className="absolute inset-0 bg-rose-200 rounded-full blur-3xl -z-10"
                />
                <span className="text-8xl font-cursive text-rose-500 glow-text leading-none">19</span>
                <span className="text-xs uppercase tracking-widest text-rose-300 font-bold mt-2">Years of Magic</span>
              </motion.div>
              <div className="max-w-xs space-y-4">
                <motion.p 
                  className="text-2xl font-cursive text-rose-600"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.8 }}
                >
                  A year of becoming beautiful things.
                </motion.p>
                <motion.p 
                  className="text-sm text-rose-400 font-light italic"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 1.2 }}
                >
                  Trust your heart. You are growing beautifully.
                </motion.p>
              </div>
              <NextButton onClick={next} label="Final Wish" />
            </div>
          )}

          {/* Page 8: Wishes & Blessings */}
          {currentPage === PageId.WISHES && (
            <div className="space-y-16 relative">
              <DecorationSparkles count={15} />
              <div className="space-y-10">
                {[
                  "May your life feel safe.",
                  "May your heart stay soft.",
                  "May you always know you are valued and respected."
                ].map((text, i) => (
                  <motion.p
                    key={i}
                    className="text-2xl font-serif italic text-rose-700 glass px-8 py-4 rounded-full inline-block mx-2"
                    initial={{ opacity: 0, scale: 0.9, y: 20 }}
                    animate={{ opacity: 1, scale: 1, y: 0 }}
                    transition={{ delay: i * 0.7 + 0.3, duration: 0.8 }}
                  >
                    {text}
                  </motion.p>
                ))}
              </div>
              <NextButton onClick={next} label="One Last Thing 💫" />
            </div>
          )}

          {/* Page 9: Final Scene */}
          {currentPage === PageId.FINAL && (
            <div className="space-y-12 relative">
              <div className="space-y-6">
                <motion.h1 
                  className="text-6xl md:text-7xl font-cursive text-rose-500 glow-text"
                  {...titleAnim}
                >
                  Happy Birthday Payal 🤍
                </motion.h1>
                <motion.h2 
                  className="text-4xl font-cursive text-rose-400"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 1, duration: 1.2 }}
                >
                  Always cheering for you, Paapu 🌸
                </motion.h2>
              </div>
              <DecorationSparkles count={20} />
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 2 }}
                className="pt-10"
              >
                <p className="text-xs uppercase tracking-[0.4em] text-rose-300 font-bold glass px-6 py-2 rounded-full inline-block">
                  Family by heart. Always.
                </p>
              </motion.div>
            </div>
          )}
        </motion.div>
      </AnimatePresence>
    </div>
  );
};

const DecorationSparkles: React.FC<{ scale?: number; count?: number }> = ({ scale = 1, count = 6 }) => (
  <div className="absolute inset-0 pointer-events-none -z-10 flex items-center justify-center overflow-visible" style={{ transform: `scale(${scale})` }}>
    {[...Array(count)].map((_, i) => (
      <motion.div
        key={i}
        className="absolute"
        animate={{
          scale: [0, 1.2, 0],
          opacity: [0, 1, 0],
          rotate: [0, 180, 360],
          x: (Math.random() - 0.5) * 500,
          y: (Math.random() - 0.5) * 500,
        }}
        transition={{
          duration: Math.random() * 4 + 3,
          repeat: Infinity,
          delay: Math.random() * 3,
          ease: "easeInOut"
        }}
      >
        <Sparkles className="text-rose-200 w-6 h-6 blur-[0.5px]" />
      </motion.div>
    ))}
  </div>
);

interface NextButtonProps {
  onClick: () => void;
  label: string;
}

const NextButton: React.FC<NextButtonProps> = ({ onClick, label }) => (
  <motion.button
    onClick={onClick}
    whileHover={{ scale: 1.08, backgroundColor: 'rgba(255, 255, 255, 0.4)' }}
    whileTap={{ scale: 0.92 }}
    initial={{ opacity: 0, y: 20 }}
    animate={{ opacity: 1, y: 0 }}
    transition={{ delay: 2.5, duration: 0.8 }}
    className="glass px-10 py-4 rounded-full text-rose-500 font-bold shadow-xl hover:shadow-rose-200 transition-all flex items-center gap-3 group border border-white/50 relative overflow-hidden"
  >
    <motion.div 
      className="absolute inset-0 bg-white/10"
      animate={{ x: ['-100%', '100%'] }}
      transition={{ duration: 3, repeat: Infinity, ease: "linear" }}
    />
    <span className="tracking-wide relative z-10">{label}</span>
    <ChevronRight className="w-5 h-5 group-hover:translate-x-1.5 transition-transform relative z-10" />
  </motion.button>
);

export default App;
