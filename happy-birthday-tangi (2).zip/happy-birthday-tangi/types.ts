
export enum PageId {
  OPENING = 1,
  NAME_REVEAL = 2,
  INTRO = 3,
  MESSAGE = 4,
  ABOUT = 5,
  PROMISE = 6,
  AGE = 7,
  WISHES = 8,
  FINAL = 9
}

export interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  duration: number;
  delay: number;
}
